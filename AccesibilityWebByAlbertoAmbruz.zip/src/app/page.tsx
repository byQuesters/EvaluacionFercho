'use client';

export default function Home() {
  return (
    <h1 className="text-4xl font-bold text-green-800 text-center mt-10">
      Bienvenido al sitio informativo
    </h1>
  );
}
